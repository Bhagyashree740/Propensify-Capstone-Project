import joblib
from flask import Flask, request, jsonify

# Initialize the Flask app
app = Flask(__name__)

# Load the trained model
model = joblib.load('model.pkl')

# Route for prediction
@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get data from the POST request
        data = request.get_json(force=True)

        # Extract the features for prediction
        features = data['features']  # Assuming the input format is {'features': [list of values]}

        # Make prediction
        prediction = model.predict([features])  # The model expects a 2D array

        # Return the prediction as JSON
        return jsonify({'prediction': prediction.tolist()})

    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True)
